// Types for @ligant/bench-chrome/vite (build time only). vite is an optional peer,
// used here for its types alone.
import type { Plugin } from 'vite';
import type { HeadOptions } from './head';

export type { HeadOptions } from './head';
export const FAVICON_SVG: string;
export function applyHead(html: string, options: HeadOptions): string;
export function benchHead(options: HeadOptions): Plugin;
