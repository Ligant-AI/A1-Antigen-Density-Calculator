// Types for @ligant/bench-chrome/head (build time only).

export type HeadTag =
  | 'icon' | 'referrer' | 'title' | 'description' | 'canonical' | 'color-scheme' | 'theme-color'
  | 'og:type' | 'og:url' | 'og:site_name' | 'og:title' | 'og:description' | 'og:image'
  | 'twitter:card' | 'twitter:title' | 'twitter:description' | 'twitter:image';

export interface HeadOptions {
  /** 'Dilution Planner' gives <title>Ligant · Dilution Planner</title>, og:title and twitter:title. */
  name: string;
  /** <meta name="description">. Required unless keep includes 'description'. */
  description?: string;
  /** The tool's mount point, '/dilution-planner/': canonical and og:url are SITE_URL + path. */
  path: string;
  /** Omitted when absent, never defaulted. */
  ogDescription?: string;
  /** Omitted when absent, never defaulted. */
  twitterDescription?: string;
  /** Relative to path, e.g. 'og-image.png': og:image and twitter:image, and twitter:card summary_large_image. */
  image?: string;
  /** 'file' (default): <link rel="icon" href="./favicon.svg">, and the Vite plugin emits the file. false: no icon. */
  favicon?: 'file' | false;
  /** false omits <meta name="referrer" content="no-referrer">. Default true. */
  referrer?: boolean;
  /** Tags the tool keeps in its own index.html; the plugin checks each is there exactly once and does not emit it. */
  keep?: HeadTag[];
}

export const HEAD_MARKER: '<!-- bench-chrome:head -->';
export const TITLE_PREFIX: string;
export const SITE_NAME: string;
export const THEME_COLOR: string;
export const FAVICON_FILE: string;
export const HEAD_TAGS: readonly HeadTag[];
export function headOptions(options: HeadOptions): unknown;
export function headTags(options: HeadOptions): Array<[HeadTag, string]>;
export function renderHead(options: HeadOptions, format?: { indent?: string }): string;
