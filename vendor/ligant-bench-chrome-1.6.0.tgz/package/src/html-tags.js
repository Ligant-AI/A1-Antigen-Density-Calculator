// Internal (not a package export): a small tag scanner for the head checks in
// ./vite.js. Not a general HTML parser; it reads start tags outside comments.

const ENTITIES = { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' };

export function decodeEntities(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') return String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10));
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}

/** The html with every comment blanked to spaces, so offsets are kept. */
export function blankComments(html) {
  return html.replace(/<!--[\s\S]*?-->/g, (c) => c.replace(/[^\n]/g, ' '));
}

/** Start tags of the given names, with decoded attributes and their offset. */
export function scanTags(html, names = ['meta', 'link', 'title']) {
  const src = blankComments(html);
  const re = new RegExp(`<(${names.join('|')})\\b((?:[^>"']|"[^"]*"|'[^']*')*)>`, 'gi');
  const out = [];
  for (const m of src.matchAll(re)) {
    const attrs = {};
    for (const a of m[2].matchAll(/([^\s"'=<>/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g)) {
      attrs[a[1].toLowerCase()] = decodeEntities(a[2] ?? a[3] ?? a[4] ?? '');
    }
    const tag = m[1].toLowerCase();
    let text;
    if (tag === 'title') {
      const end = src.toLowerCase().indexOf('</title>', m.index);
      text = decodeEntities(src.slice(m.index + m[0].length, end < 0 ? undefined : end));
    }
    out.push({ tag, attrs, text, index: m.index });
  }
  return out;
}

/** The head-tag key a scanned tag represents ('og:url', 'icon', ...), or null. */
export function tagKey({ tag, attrs }) {
  if (tag === 'title') return 'title';
  if (tag === 'link') {
    const rel = (attrs.rel || '').toLowerCase().split(/\s+/);
    if (rel.includes('icon')) return 'icon';
    if (rel.includes('canonical')) return 'canonical';
    return null;
  }
  if (tag === 'meta') return (attrs.name || attrs.property || '').toLowerCase() || null;
  return null;
}
