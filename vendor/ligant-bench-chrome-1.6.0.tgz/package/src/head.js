// @ligant/bench-chrome/head: the suite's standard <head> metadata, as a string.
//
// Build time only. A pure function: it reads nothing, contacts nothing and
// returns <meta> and <link> tags plus the <title>. It emits no CSP, no <script>,
// no <style> and no style= attribute, so no tool's Content-Security-Policy has to
// change for it. `charset`, `viewport` and the CSP meta stay in each tool's own
// index.html, ahead of these tags: a meta CSP governs only what follows it.
// The Vite plugin in ./vite.js puts the output where a tool's index.html has the
// marker `<!-- bench-chrome:head -->`.
//
// Optional fields are omitted when absent, never defaulted from another field:
// an og:description copied from the meta description would publish text that
// was approved for one place only (C5, Task 12).

import { SITE_URL, escapeHtml as esc } from './index.js';

export const HEAD_MARKER = '<!-- bench-chrome:head -->';
export const TITLE_PREFIX = 'Ligant · ';
export const SITE_NAME = 'Ligant Bench Tools';
/** Equal to --brand-offwhite in ./tokens.css (a test asserts it). */
export const THEME_COLOR = '#FAF7F2';
export const FAVICON_FILE = 'favicon.svg';

/** Every tag the renderer can own, in the order it emits them. */
export const HEAD_TAGS = Object.freeze([
  'icon', 'referrer', 'title', 'description', 'canonical', 'color-scheme', 'theme-color',
  'og:type', 'og:url', 'og:site_name', 'og:title', 'og:description', 'og:image',
  'twitter:card', 'twitter:title', 'twitter:description', 'twitter:image',
]);

const OPTIONS = new Set(['name', 'description', 'path', 'ogDescription', 'twitterDescription', 'image', 'favicon', 'referrer', 'keep']);

const fail = (msg) => { throw new Error(`[bench-chrome/head] ${msg}`); };
const nonEmpty = (v) => typeof v === 'string' && v.trim() !== '';

/** Checks the options and returns them normalised. Throws on anything wrong. */
export function headOptions(o) {
  if (!o || typeof o !== 'object') fail('options object required');
  for (const k of Object.keys(o)) if (!OPTIONS.has(k)) fail(`unknown option "${k}"`);
  const { name, description, path, ogDescription, twitterDescription, image, favicon = 'file', referrer = true, keep = [] } = o;
  if (!Array.isArray(keep)) fail('keep must be an array of tag names');
  for (const k of keep) if (!HEAD_TAGS.includes(k)) fail(`keep: "${k}" is not a tag this renderer emits (${HEAD_TAGS.join(', ')})`);
  const kept = new Set(keep);
  if (!nonEmpty(name)) fail('name is required');
  if (!nonEmpty(path) || !path.startsWith('/') || !path.endsWith('/')) fail(`path must start and end with "/", got ${JSON.stringify(path)}`);
  if (!kept.has('description') && !nonEmpty(description)) fail('description is required (or keep: ["description"] to leave it in index.html)');
  if (kept.has('description') && description !== undefined) fail('description is kept in index.html, so it must not also be passed here');
  for (const [k, v] of [['ogDescription', ogDescription], ['twitterDescription', twitterDescription], ['image', image]]) {
    if (v !== undefined && !nonEmpty(v)) fail(`${k} must be a non-empty string when given`);
  }
  if (image !== undefined && (/^[a-z][a-z0-9+.-]*:/i.test(image) || image.startsWith('/'))) fail('image is relative to path, e.g. "og-image.png"');
  if (favicon !== 'file' && favicon !== false) fail('favicon is "file" or false');
  if (typeof referrer !== 'boolean') fail('referrer is true or false');
  return { name, description, path, ogDescription, twitterDescription, image, favicon, referrer, kept };
}

/** The tags as [key, html] pairs, in emission order. */
export function headTags(options) {
  const o = headOptions(options);
  const url = `${SITE_URL}${o.path}`;
  const title = `${TITLE_PREFIX}${o.name}`;
  const img = o.image === undefined ? undefined : `${url}${o.image}`;
  const meta = (attr, key, content) => `<meta ${attr}="${esc(key)}" content="${esc(content)}">`;
  const all = [
    ['icon', o.favicon === 'file' ? `<link rel="icon" type="image/svg+xml" href="./${FAVICON_FILE}">` : null],
    ['referrer', o.referrer ? meta('name', 'referrer', 'no-referrer') : null],
    ['title', `<title>${esc(title)}</title>`],
    ['description', o.description === undefined ? null : meta('name', 'description', o.description)],
    ['canonical', `<link rel="canonical" href="${esc(url)}">`],
    ['color-scheme', meta('name', 'color-scheme', 'light')],
    ['theme-color', meta('name', 'theme-color', THEME_COLOR)],
    ['og:type', meta('property', 'og:type', 'website')],
    ['og:url', meta('property', 'og:url', url)],
    ['og:site_name', meta('property', 'og:site_name', SITE_NAME)],
    ['og:title', meta('property', 'og:title', title)],
    ['og:description', o.ogDescription === undefined ? null : meta('property', 'og:description', o.ogDescription)],
    ['og:image', img === undefined ? null : meta('property', 'og:image', img)],
    ['twitter:card', meta('name', 'twitter:card', img === undefined ? 'summary' : 'summary_large_image')],
    ['twitter:title', meta('name', 'twitter:title', title)],
    ['twitter:description', o.twitterDescription === undefined ? null : meta('name', 'twitter:description', o.twitterDescription)],
    ['twitter:image', img === undefined ? null : meta('name', 'twitter:image', img)],
  ];
  return all.filter(([k, html]) => html !== null && !o.kept.has(k));
}

/**
 * The standard head tags, one per line.
 * @param {import('../head').HeadOptions} options
 * @returns {string}
 */
export function renderHead(options, { indent = '' } = {}) {
  return headTags(options).map(([, html]) => html).join(`\n${indent}`);
}
