// @ligant/bench-chrome/vite: benchHead(), a build-time Vite plugin over
// renderHead() in ./head.js.
//
// It replaces the one marker `<!-- bench-chrome:head -->` in a tool's index.html
// with the standard head tags, in place, so the tags sit exactly where the tool
// put the marker: after its CSP meta. It never prepends (`head-prepend` would
// put the icon link ahead of the policy). It writes favicon.svg (the Ligant
// mark, the same SVG as markDataUri()) into the build, and serves it from the
// dev server, where generateBundle does not run.
//
// The build fails if the marker is missing or appears twice, if a
// Content-Security-Policy meta follows the marker, if a tag the plugin emits is
// already in the source (a leftover canonical, say), if a tag named in `keep`
// is not in the source exactly once, or if public/favicon.svg would collide with
// the emitted one.
//
// A plain object: no dependency on vite at runtime. Nothing here reaches a
// tool's runtime bundle.

import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { markDataUri } from './index.js';
import { HEAD_MARKER, HEAD_TAGS, FAVICON_FILE, headOptions, renderHead } from './head.js';
import { blankComments, scanTags, tagKey } from './html-tags.js';

/** favicon.svg: the decoded markDataUri(), byte for byte. */
export const FAVICON_SVG = decodeURIComponent(markDataUri().slice('data:image/svg+xml,'.length));

const fail = (msg) => { throw new Error(`[bench-chrome/vite] ${msg}`); };
const CSP = /<meta\b[^>]*http-equiv\s*=\s*["']?content-security-policy/gi;

/**
 * Replaces the marker in `html` with renderHead(options), after checking the
 * page. Pure; exported so a tool's tests (and Swatch) can call it directly.
 */
export function applyHead(html, options) {
  const o = headOptions(options);
  const at = [];
  for (let i = html.indexOf(HEAD_MARKER); i >= 0; i = html.indexOf(HEAD_MARKER, i + 1)) at.push(i);
  if (at.length === 0) fail(`no ${HEAD_MARKER} marker in index.html; put it in <head>, after the CSP meta`);
  if (at.length > 1) fail(`${HEAD_MARKER} appears ${at.length} times; it must appear once`);
  const pos = at[0];
  const plain = blankComments(html.slice(0, pos)) + HEAD_MARKER + blankComments(html.slice(pos + HEAD_MARKER.length));
  const headEnd = plain.search(/<\/head\s*>/i);
  if (headEnd >= 0 && pos > headEnd) fail(`${HEAD_MARKER} is after </head>`);
  for (const m of plain.matchAll(CSP)) {
    if (m.index > pos) fail(`a Content-Security-Policy meta follows ${HEAD_MARKER}; a meta CSP governs only what comes after it, so the marker must follow the CSP`);
  }
  const counts = new Map();
  for (const t of scanTags(html)) {
    const k = tagKey(t);
    if (HEAD_TAGS.includes(k)) counts.set(k, (counts.get(k) || 0) + 1);
  }
  for (const k of HEAD_TAGS) {
    const n = counts.get(k) || 0;
    if (o.kept.has(k)) {
      if (n !== 1) fail(`keep: ["${k}"] needs exactly one ${k} tag in index.html, found ${n}`);
    } else if (n > 0) {
      fail(`index.html already has a ${k} tag; the plugin emits it, so delete it from the source (or list it in keep)`);
    }
  }
  const lineStart = html.lastIndexOf('\n', pos) + 1;
  const lead = html.slice(lineStart, pos);
  const indent = /^[ \t]*$/.test(lead) ? lead : '';
  return html.slice(0, pos) + renderHead(options, { indent }) + html.slice(pos + HEAD_MARKER.length);
}

/**
 * @param {import('../head').HeadOptions} options
 * @returns {import('vite').Plugin}
 */
export function benchHead(options) {
  const o = headOptions(options); // fail at config load, not mid-build
  const favicon = o.favicon === 'file';
  return {
    name: 'bench-chrome:head',
    configResolved(config) {
      if (favicon && config.publicDir && existsSync(join(config.publicDir, FAVICON_FILE))) {
        fail(`public/${FAVICON_FILE} exists, and the plugin emits ${FAVICON_FILE}; delete the public copy`);
      }
    },
    transformIndexHtml: {
      order: 'pre',
      handler(html, ctx) {
        // Only the page itself. Other HTML entries (a verification mock, say) pass through.
        if (ctx && ctx.path && !/(^|\/)index\.html$/.test(ctx.path)) return html;
        return applyHead(html, options);
      },
    },
    configureServer(server) {
      if (!favicon) return;
      server.middlewares.use((req, res, next) => {
        const p = (req.url || '').split('?')[0];
        if (!p.endsWith(`/${FAVICON_FILE}`)) return next();
        res.setHeader('Content-Type', 'image/svg+xml');
        res.end(FAVICON_SVG);
      });
    },
    generateBundle() {
      if (favicon) this.emitFile({ type: 'asset', fileName: FAVICON_FILE, source: FAVICON_SVG });
    },
  };
}
