# @ligant/bench-chrome

The header and footer every [Ligant Bench Tool](https://benchtools.ligant.ai/) shares: the Ligant lockup, the tool switcher, the standard privacy statement, the citation block and the licence. A tool supplies only what is its own. Everything else is written once, here.

- **Framework-free.** Every renderer returns an HTML string. Plain-JS tools set it as `innerHTML`; React tools use the thin wrappers in `@ligant/bench-chrome/react`.
- **Asks before Google Analytics.** From 1.1.0 the footer starts the suite's privacy choice (`src/consent.js`). Nothing Google is requested and nothing is stored until the visitor clicks Allow; then Google Analytics (`G-9V1GYE3KRX`) loads from `www.googletagmanager.com` with host-only cookies and a `page_location` of origin plus path only. Decline, ignoring the banner, or a GPC signal load nothing. The footer's "Privacy choices" link reopens it. It runs only on hosted addresses (`ligant.ai`, its subdomains, `*.pages.dev`): a copy someone runs themselves, a preview, or the single-file build opened from disk shows no banner and never contacts Google. The renderers themselves contact nothing; the addresses they embed are `https://benchtools.ligant.ai`, `https://ligant.ai/`, `https://ligant.ai/privacy` (and `#google-analytics`) and the tool's own repository.
- **Built into each tool, not loaded at runtime.** Each tool pins a version, so a deployed page is reproducible from its own commit.
- **Optional tokens, fonts and head metadata** (from 1.4.0): separate exports a tool adopts one at a time; see below.
- **Vendored, so the tools stay buildable by anyone.** This repository is private. Each release is packed into one file that is committed into every tool's own repository, so a reader who clones a tool can install and run it with no access to this repository and no network. The code is Apache-2.0, like the tools it ships in.

## Install

In a tool's repository, with the release tarball copied into `vendor/`:

```sh
npm install ./vendor/ligant-bench-chrome-1.0.0.tgz
```

Then import the stylesheet once from the tool's entry point:

```js
import '@ligant/bench-chrome/chrome.css';
```

The stylesheet uses the suite's design tokens (`--border`, `--text-primary`, `--brand-teal`, `--surface`, `--font`, `--mono` and the rest), which every tool defines. Every selector is scoped under `.masthead` or `.site-footer`.

## What a tool supplies

| Option | Header | Footer | Example |
|---|---|---|---|
| `path` | ✓ | | `'/dilution-planner/'`, the tool's own mount point; the switcher marks it as the current page |
| `title` | ✓ | | `'Dilution Planner'` |
| `description` | ✓ | | a string, or an array of paragraphs |
| `repoUrl` | | ✓ | `'https://github.com/Ligant-AI/C3-Dilution-Planner'`, the tool's own repository |
| `citations` | | ✓ | `[{ lead, title, tail, what }]`, shown as lead + *title* + tail and copied as the same |
| `disclaimer` | | ✓ | `'Research use only. Not qualified for GxP decision-making.'` |
| `citationNote` | | optional | default `'Cite the software as below.'` |
| `citationFootnote` | | optional | a note under the citations |
| `localCopyHtml` | | optional | trusted markup after the repository link; default `Clone it and <code>npm run dev</code> for a local copy.` |

Keep `repoUrl` in the tool's own config (`site.ts` or `config.js`), where its checks and `CITATION.cff` can see it.

## Plain JS

```html
<header class="masthead" id="site-header"></header>
…
<footer class="site-footer" id="site-footer"></footer>
```

```js
import { renderHeader, renderFooter, bindCopy } from '@ligant/bench-chrome';

document.getElementById('site-header').innerHTML = renderHeader({ path, title, description });
const footer = document.getElementById('site-footer');
footer.innerHTML = renderFooter({ repoUrl, citations, disclaimer });
bindCopy(footer);
```

## React

```tsx
import { SuiteHeader, SuiteFooter, LigantMark } from '@ligant/bench-chrome/react';

<SuiteHeader path={TOOL_PATH} title="Antigen Density Calculator" description="Quantifies…" />
…
<SuiteFooter repoUrl={REPO_URL} citations={[…]} disclaimer="Research use only. …" />
```

`LigantMark` renders the mark alone, for a colophon.

## What a tool must allow (from 1.1.0)

The privacy choice loads Google Analytics after Allow, so a tool's Content-Security-Policy, in its `_headers` and in any `<meta http-equiv>` copy, must allow exactly:

```
script-src  https://www.googletagmanager.com
connect-src https://*.google-analytics.com https://*.analytics.google.com https://*.googletagmanager.com https://www.google.com https://*.g.doubleclick.net
img-src     https://*.google-analytics.com https://*.googletagmanager.com
```

and the tool's network check must allow those hosts **only after Allow**, and must type a sentinel into every input, click Allow, use the tool, and fail if the sentinel appears in any request.

## Newsletter signup

`renderFooter` opens with a newsletter signup, and `bindCopy` wires it (or call `bindNewsletter(root)`). It posts same-origin to `/api/subscribe`, which the catalog Worker on benchtools.ligant.ai forwards to the ligant.ai Worker; nothing joins the list until the person confirms by email. The form is shown only on `benchtools.ligant.ai`; anywhere else a link to the signup on ligant.ai is shown instead.

Each tool must allow that one address in its CSP: add `https://benchtools.ligant.ai/api/subscribe` to `connect-src` (in `public/_headers` and in any meta CSP in `index.html`). `check-consent.mjs` skips the signup when typing its sentinel into every field, then checks the signup on its own: nothing sent before submit, one same-origin POST carrying only email, consent and honeypot, and no tool value or the address anywhere else. Tools whose own checks type into every field must skip `[data-newsletter]` the same way and keep the positive check.

## Tokens, fonts and head metadata (opt-in, from 1.4.0)

Four further exports. None is loaded by the header and footer: `chrome.css` does not import tokens or fonts, and `.`, `./react` and `./consent` are unchanged, so a tool that only updates the tarball builds exactly as before. A tool adopts each piece on its own, in any order.

| Export | What it is |
|---|---|
| `@ligant/bench-chrome/tokens.css` | The suite's `:root` design tokens, the single source. `@import` it as the first line of the tool's own stylesheet. |
| `@ligant/bench-chrome/fonts.css` | Inter 400/600/700 and IBM Plex Mono 400/600, full character sets, woff2 (`fonts/`). For C3, C5 and C7. |
| `@ligant/bench-chrome/fonts-latin.css` | The same five faces and family names, latin subset, woff2 with woff fallback (`fonts/latin/`). For A1 and C4. |
| `@ligant/bench-chrome/head` | `renderHead(options)`: the standard `<head>` tags as a string, at build time. |
| `@ligant/bench-chrome/vite` | `benchHead(options)`: a Vite plugin that puts `renderHead(options)` where `index.html` has `<!-- bench-chrome:head -->`. |

Import one font file, not both. The bundler copies the font files to the tool's own origin under hashed names, so `font-src 'self'` covers them; none may be inlined as a `data:` URI (every file is above Vite's 4 KB inline limit).

### Head metadata

```js
// vite.config.js
import { benchHead } from '@ligant/bench-chrome/vite';
export default defineConfig({
  plugins: [benchHead({
    name: 'Dilution Planner',          // <title>Ligant · Dilution Planner</title>, og:title, twitter:title
    description: '…',                  // <meta name="description">
    path: '/dilution-planner/',        // canonical and og:url
    ogDescription: '…',                // optional; omitted when absent, never defaulted
    twitterDescription: '…',           // optional; omitted when absent, never defaulted
    image: 'og-image.png',             // optional, relative to path; sets twitter:card summary_large_image
    // favicon: 'file' (default) | false; referrer: true (default) | false; keep: ['description']
  })],
});
```

```html
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="…">   <!-- stays the tool's own -->
<!-- bench-chrome:head -->
```

The plugin emits `<link rel="icon" href="./favicon.svg">`, the referrer meta (`no-referrer`), the title, the description, canonical, `color-scheme`, `theme-color` (`#FAF7F2`, `--brand-offwhite`), `og:type`, `og:url`, `og:site_name`, `og:title`, and `og:description`, `og:image`, `twitter:*` as supplied. It writes `favicon.svg` (the Ligant mark, the same SVG as `markDataUri()`) into the build and serves it from the dev server. It emits no CSP, script or style; `charset`, `viewport` and the CSP meta stay in the tool's `index.html`, ahead of the marker. The build fails if the marker is missing or appears twice, if a CSP meta follows it, if a tag the plugin emits is already in the source, if a `keep` tag is not there exactly once, or if `public/favicon.svg` exists.

`keep: ['description']` leaves a tag the tool keeps in its own `index.html` (C5's approved description) where it is. `referrer: false` omits the referrer meta.

## Third-party fonts

The fonts are licensed under the SIL Open Font License 1.1, not Apache-2.0, so the package licence is `Apache-2.0 AND OFL-1.1`. They are shipped unmodified, each with its licence text beside it; see [NOTICE](NOTICE).

| Files | Font | Source |
|---|---|---|
| `fonts/Inter-{Regular,SemiBold,Bold}.woff2` | Inter 4.001 (git-9221beed3), © 2016 The Inter Project Authors | the files C3, C5 and C7 shipped (C7-Reconstitution 83a05d4, `fonts/`) |
| `fonts/IBMPlexMono-{Regular,SemiBold}.woff2` | IBM Plex Mono 2.004, © 2017 IBM Corp., Reserved Font Name "Plex" | as above |
| `fonts/latin/*` | the latin subsets of both | `@fontsource/inter@5.3.0`, `@fontsource/ibm-plex-mono@5.3.0` as published (the files A1 and C4 shipped); prebuilt by Fontsource, not subset here |

**Open questions for Clause:**
- **Q-L1:** must the OFL texts also be served in each tool's deployed build? No tool serves them today. Is `Apache-2.0 AND OFL-1.1` plus this section and NOTICE the right package metadata, and should NOTICE carry a copyright line for the package's own code?
- **Q-L2:** `fonts/latin/` distributes a subset of IBM Plex Mono, whose licence reserves the name "Plex". Is a subset a Modified Version under that Reserved Font Name? (Fontsource's licence text for Plex does not repeat the Reserved Font Name line that IBM's does.)
- **Q-L3:** confirm that the full-set files match the upstream releases (Inter 4.001, IBM Plex Mono 2.004), and record their source URLs here.

## Changing the chrome

1. Change it here, add a test, and bump the version in `package.json`.
2. Commit, then `git tag vX.Y.Z` and push the tag.
3. Roll it out: `scripts/rollout.sh X.Y.Z` packs the release and, for each live tool, copies the tarball into `vendor/`, updates the dependency, runs the tool's own checks, and opens a pull request. Nothing is merged or deployed by the script; review and merge each pull request, then deploy.

A header lists a new tool only once that tool's own deployment has been rebuilt, so add a tool to `TOOLS` only once it is live.

## Licence

The code is under the Apache License, Version 2.0. See [LICENSE](LICENSE). The fonts in `fonts/` are under the SIL Open Font License 1.1; see [Third-party fonts](#third-party-fonts) and [NOTICE](NOTICE).
